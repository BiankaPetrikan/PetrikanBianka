import pandas as pd
import os
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.express as px
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
import numpy as np
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.preprocessing import LabelEncoder


current_dir = os.getcwd()
data_path = os.path.join(current_dir, '3_varhato_elettartam.csv')

df = pd.read_csv(data_path)

# Adattisztítás
df.columns = df.columns.str.strip()

df.dropna(inplace=True)

# Dátumok kezelése
if 'Year' in df.columns:
    df['Year'] = pd.to_datetime(df['Year'], format='%Y', errors='coerce')
    df.dropna(subset=['Year'], inplace=True)

# Egy főre jutó GDP
if 'GDP' in df.columns and 'Population' in df.columns:
    df['GDP per capita'] = df['GDP'] / df['Population']

# Szükséges adatok
population_min = df['Population'].min()
population_max = df['Population'].max()
population_25 = np.percentile(df['Population'], 25)
population_50 = np.median(df['Population'])
population_75 = np.percentile(df['Population'], 75)

gdp_min = df['GDP'].min()
gdp_max = df['GDP'].max()
gdp_25 = np.percentile(df['GDP'], 25)
gdp_50 = np.median(df['GDP'])
gdp_75 = np.percentile(df['GDP'], 75)

# Dash alkalmazás
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = html.Div(
    style={'backgroundColor': '#e8f5e9', 'padding': '15px'},  # Világos zöld háttér
    children=[
        # Projekt információk
        dcc.Tabs(
            id='tabs',
            value='tab-1',
            children=[
                dcc.Tab(label='Szerzői adatok', value='tab-1', children=[
                    html.Div([
                        html.P("Név: Petrikán Bianka", style={'color': '#004d40'}),
                        html.P("Neptun-kód: JPW9G0", style={'color': '#004d40'}),
                        html.P("E-mail: petrikanbia@gmail.com", style={'color': '#004d40'})
                    ])
                ]),
                dcc.Tab(label='Projekt adatok', value='tab-2', children=[
                    html.Div([
                        html.P(
                            "Projekt célja: Az élettartam és gazdasági mutatók elemzése és prezentálása felhasználóbarát applikációban.",
                            style={'marginTop': '10px', 'color': '#004d40'}),
                        html.P("A megvalósítás módja: Dash alkalmazás",
                               style={'marginTop': '10px', 'color': '#004d40'}),
                        html.P("Adathalmaz értelmezése: ", style={'marginTop': '10px', 'color': '#004d40'}),
                        html.P(
                            """
                            Az adathalmaz, amely a különböző országok egészségügyi és demográfiai mutatóit tartalmazza, 
                            a következő oszlopokkal rendelkezik:

                            1. Total expenditure: Az országok egészségügyi kiadásainak összesített értéke.
                            2. Diphtheria: A diftéria elleni védőoltások aránya.
                            3. HIV/AIDS: A HIV/AIDS előfordulásának mértéke.
                            4. GDP: Az ország bruttó hazai terméke, amely az ország gazdasági teljesítményének fontos mutatója.
                            5. Population: Az adott ország lakosságának száma.
                            6. Thinness 1-19 years: A 1-19 éves korosztály körében mért vékonyság aránya.
                            7. Thinness 5-9 years: Az 5-9 éves korú gyermekek körében mért vékonyság aránya.
                            8. Income composition of resources: Az erőforrások jövedelmi összetétele, amely a gazdasági egyenlőtlenség mértékét tükrözi.
                            9. Schooling: Az oktatás szintje és elérhetősége, amely hatással van a társadalmi fejlődésre.

                            Az adathalmaz célja, hogy a különböző demográfiai és gazdasági mutatók alapján 
                            megértsük az egészségügyi állapotokat, és előrejelzéseket végezzünk a várható élettartammal kapcsolatban.
                            """,
                            style={'marginTop': '10px', 'color': '#004d40'}
                        ),
                    ])
                ])
            ]
        ),
        # Főcím
        html.H1("Várható élettartam elemzése demográfiai és gazdasági adatok alapján",
                style={'textAlign': 'center', 'color': '#004d40', 'marginBottom': '15px'}),

        # Ország kiválasztása
        html.Div(
            style={'marginBottom': '30px'},
            children=[
                html.Label("Válaszd ki az országot:", style={'color': '#00695c'}),
                dcc.Dropdown(
                    id='country-dropdown',
                    options=[{'label': country, 'value': country} for country in df['Country'].unique()],
                    value=None
                ),
                html.Div(id='gdp-output', style={'marginTop': '15px', 'color': '#004d40'})
            ]
        ),

        # Csuszka: Népesség és GDP tartomány
        html.Div(
            style={'marginBottom': '30px'},
            children=[
                html.Label("Népesség tartomány:", style={'color': '#00695c'}),
                dcc.Slider(
                    id='population-slider',
                    min=0,
                    max=4,
                    step=1,
                    value=0,
                    marks={
                        0: {'label': f"{int(population_min / 1e9)}M", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        1: {'label': f"{int(population_25 / 1e9)}M", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        2: {'label': f"{int(population_50 / 1e9)}M", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        3: {'label': f"{int(population_75 / 1e9)}M", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        4: {'label': f"{int(population_max / 1e9)}M", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}}
                    }
                ),
                html.Label("GDP tartomány:", style={'marginTop': '15px', 'color': '#00695c'}),
                dcc.Slider(
                    id='gdp-slider',
                    min=0,
                    max=4,
                    step=1,
                    value=0,
                    marks={
                        0: {'label': f"{int(gdp_min / 1e3)}K", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        1: {'label': f"{int(gdp_25 / 1e3)}K", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        2: {'label': f"{int(gdp_50 / 1e3)}K", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        3: {'label': f"{int(gdp_75 / 1e3)}K", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}},
                        4: {'label': f"{int(gdp_max / 1e3)}K", 'style': {'color': '#388e3c', 'fontWeight': 'bold'}}
                    }
                ),
                html.Div(id='filtered-countries-output', style={'marginTop': '15px', 'color': '#004d40'})
            ]
        ),

        # Élettartam megjelenítés
        html.Div(
            style={'marginBottom': '30px'},
            children=[
                html.Label("Válassz országokat az élettartam ábrázolásához:", style={'color': '#00695c'}),
                dcc.Dropdown(
                    id='life-expectancy-dropdown',
                    options=[{'label': country, 'value': country} for country in df['Country'].unique()],
                    multi=True,
                    value=None
                ),
                html.Div(id='life-expectancy-output', style={'marginTop': '15px', 'color': '#004d40'})
            ]
        ),

        # Gyakorisági diagram
        html.Div(
            style={'marginBottom': '30px'},
            children=[
                html.Label("Év választása a gyakorisági diagramhoz:", style={'color': '#00695c'}),
                dcc.Slider(
                    id='year-slider',
                    min=df['Year'].dt.year.min(),
                    max=df['Year'].dt.year.max(),
                    step=1,
                    value=df['Year'].dt.year.min(),
                    marks={year: str(year) for year in range(df['Year'].dt.year.min(), df['Year'].dt.year.max() + 1, 5)}
                ),
                html.Label("Változó kiválasztása a gyakorisági diagramhoz:", style={'marginTop': '15px', 'color': '#00695c'}),
                dcc.Dropdown(
                    id='variable-dropdown',
                    options=[{'label': col, 'value': col} for col in df.columns if col not in ['Country', 'Year']],
                    value=None
                ),
                html.Div(id='histogram-output', style={'marginTop': '15px', 'color': '#004d40'})
            ]
        ),

        # Tematikus térkép
        html.Div(
            style={'marginBottom': '30px'},
            children=[
                html.Label("Év választása a térképhez:", style={'color': '#00695c'}),
                dcc.Slider(
                    id='choropleth-year-slider',
                    min=df['Year'].dt.year.min(),
                    max=df['Year'].dt.year.max(),
                    step=1,
                    value=df['Year'].dt.year.min(),
                    marks={year: str(year) for year in range(df['Year'].dt.year.min(), df['Year'].dt.year.max() + 1, 5)}
                ),
                html.Label("Változó kiválasztása a térképhez:", style={'marginTop': '15px', 'color': '#00695c'}),
                dcc.Dropdown(
                    id='choropleth-variable-dropdown',
                    options=[{'label': col, 'value': col} for col in df.columns if col not in ['Country', 'Year']],
                    value=None
                ),
                html.Div(id='choropleth-output', style={'marginTop': '15px', 'color': '#004d40'})
            ]
        ),


    ]
)


# Egy főre jutó gdp
@app.callback(
    dash.dependencies.Output('gdp-output', 'children'),
    [dash.dependencies.Input('country-dropdown', 'value')]
)
def update_gdp_output(selected_country):
    if selected_country is None:
        return html.P("Válassz ki egy országot az alábbi listából.")

    filtered_df = df[df['Country'] == selected_country]
    fig = px.line(filtered_df, x=filtered_df['Year'].dt.year, y='GDP per capita',
                  title=f'{selected_country} egy főre jutó GDP-je évekre lebontva')
    fig.update_layout(
        paper_bgcolor='#f0f0f0',
        plot_bgcolor='#ffffff',
        title={'x': 0.5},
        xaxis_title='Év',
        yaxis_title='Egy főre jutó GDP',
        margin={'l': 40, 'r': 40, 't': 40, 'b': 40},
        hovermode='x'
    )
    return dcc.Graph(figure=fig)

# Népesség és GDP callback
@app.callback(
    dash.dependencies.Output('filtered-countries-output', 'children'),
    [dash.dependencies.Input('population-slider', 'value'),
     dash.dependencies.Input('gdp-slider', 'value')]
)
def update_filtered_countries(population_value, gdp_value):
    population_ranges = [population_min, population_25, population_50, population_75, population_max]
    gdp_ranges = [gdp_min, gdp_25, gdp_50, gdp_75, gdp_max]

    population_min_selected = population_ranges[population_value]
    population_max_selected = population_ranges[min(population_value + 1, 4)]

    gdp_min_selected = gdp_ranges[gdp_value]
    gdp_max_selected = gdp_ranges[min(gdp_value + 1, 4)]

    # Szűrjük a DataFrame-et a kiválasztott népesség és GDP tartomány alapján
    filtered_df = df[(df['Population'] >= population_min_selected) & (df['Population'] <= population_max_selected) &
                     (df['GDP'] >= gdp_min_selected) & (df['GDP'] <= gdp_max_selected)]

    if filtered_df.empty:
        return html.P("Nincs olyan ország, amely megfelel a megadott feltételeknek.")

    # Megjelenítjük az országokat listában
    return html.Ul(
        [html.Li(f"{row['Country']} - Fejlettségi szint: {row['Status']}") for _, row in filtered_df.iterrows()]
    )

# Várható élettartam callback
@app.callback(
    dash.dependencies.Output('life-expectancy-output', 'children'),
    [dash.dependencies.Input('life-expectancy-dropdown', 'value')]
)
def update_life_expectancy_output(selected_countries):
    if not selected_countries:
        return html.P("Válassz ki egy vagy több viszgálni kívánt országot az alábbi listából.")

    filtered_df = df[df['Country'].isin(selected_countries)]
    fig = px.line(filtered_df, x=filtered_df['Year'].dt.year, y='Life expectancy', color='Country',
                  title='Várható élettartam alakulása évek szerint')
    fig.update_layout(
        paper_bgcolor='#f0f0f0',
        plot_bgcolor='#ffffff',
        title={'x': 0.5},
        xaxis_title='Év',
        yaxis_title='Várható élettartam',
        margin={'l': 40, 'r': 40, 't': 40, 'b': 40},
        hovermode='x'
    )
    return dcc.Graph(figure=fig)

# Callback a gyakorisági diagram megjelenítésére
@app.callback(
    dash.dependencies.Output('histogram-output', 'children'),
    [dash.dependencies.Input('year-slider', 'value'),
     dash.dependencies.Input('variable-dropdown', 'value')]
)
def update_histogram(year, selected_variable):
    if not selected_variable:
        return html.P("Válassz ki egyet az alábbi értékekből.")

    filtered_df = df[df['Year'].dt.year == year]
    if filtered_df.empty:
        return html.P("Nincs rögzített adat ebben az évben.")

    fig = px.histogram(filtered_df, x=selected_variable, nbins=20, title=f'{selected_variable} eloszlása {year}-ban')
    fig.update_layout(
        paper_bgcolor='#f0f0f0',
        plot_bgcolor='#ffffff',
        title={'x': 0.5},
        xaxis_title=selected_variable,
        yaxis_title='Gyakoriság',
        margin={'l': 40, 'r': 40, 't': 40, 'b': 40}
    )
    return dcc.Graph(figure=fig)

# Tematikus térkép callback
@app.callback(
    dash.dependencies.Output('choropleth-output', 'children'),
    [dash.dependencies.Input('choropleth-year-slider', 'value'),
     dash.dependencies.Input('choropleth-variable-dropdown', 'value')]
)
def update_choropleth(year, selected_variable):
    if not selected_variable:
        return html.P("Válassz egy értéket az allábbi listából.")

    filtered_df = df[df['Year'].dt.year == year]
    if filtered_df.empty:
        return html.P("Nincs adat a kiválasztott évre.")

    fig = px.choropleth(filtered_df, locations='Country', locationmode='country names', color=selected_variable,
                        hover_name='Country', title=f'{selected_variable} tematikus térképe {year}-ban')
    fig.update_layout(
        paper_bgcolor='#f0f0f0',
        geo=dict(bgcolor='#f0f0f0'),
        title={'x': 0.5},
        margin={'l': 40, 'r': 40, 't': 40, 'b': 40}
    )
    return dcc.Graph(figure=fig)


if __name__ == '__main__':
    app.run_server(debug=True)